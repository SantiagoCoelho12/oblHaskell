Obligatorio Algoritmos, estructuras de datos y lenguajes avanzados
Universidad ORT Uruguay
2024

Santiago Coelho 204113
Luca Bessonart 231764

Tarea Elegida: Monadas
Se creo un programa que realiza lo siguente:
    - Se puede jugar al juego Mastermind con dos dificultades
    - Se creo un log con lectura/escritura de archivos como historico de partidas
    - Se programo una funcion para que dado un codigo la computadora lo adivine (Falla en ciertos casos, funcion autogueser)
